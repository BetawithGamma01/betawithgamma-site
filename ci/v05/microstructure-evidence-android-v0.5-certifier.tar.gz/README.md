# NIFTY Microstructure Evidence Android V0.5 — Decoder + Certifier

This release is an evidence kernel, not a charting product.

Implemented:

- FYERS TBT protobuf depth decoder bound to the inspected SDK 3.1.15 descriptor.
- Deterministic 50-level snapshot/diff reconstruction using `MarketLevel.num`.
- FYERS sequence-gap fail-closed state machine.
- Dhan 20-level 332-byte stacked-packet decoder.
- Strict crossed/non-monotonic book rejection.
- Dhan standard FULL structured diagnostics with bounded explicit reconnect.
- Foreground-service watchdog ticks and scheduler-gap evidence.
- Separate lifecycle and quality status (`SEALED`, `PASS`, `PARTIAL`, `FAILED_QUALITY`).
- Installed APK hash, signing-certificate hash, Git commit and source-tree hash provenance.
- Android Keystore P-256 ECDSA evidence sealing.
- Verify-before-export.

Deliberately absent:

- DOM/heatmap UI
- strategies or signals
- orders/execution
- true CVD
- footprint
- exact time-and-sales claims

See `docs/EVIDENCE_CONTRACT.md` and `evidence/CROSS_IMPLEMENTATION_EVIDENCE.json`.
