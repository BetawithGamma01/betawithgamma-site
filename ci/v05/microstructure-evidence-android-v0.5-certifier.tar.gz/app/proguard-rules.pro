# V0 deliberately keeps symbols: evidence capture is more important than APK size.
