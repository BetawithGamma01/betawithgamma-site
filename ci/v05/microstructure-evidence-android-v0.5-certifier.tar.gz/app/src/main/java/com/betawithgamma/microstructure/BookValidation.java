package com.betawithgamma.microstructure;

public final class BookValidation {
    private BookValidation() {}

    public static String validateLong50(FyersBookReconstructor.Level[] asks, FyersBookReconstructor.Level[] bids){
        if(asks.length!=50||bids.length!=50)return "DEPTH_LENGTH";
        for(int i=0;i<50;i++){
            var a=asks[i]; var b=bids[i];
            if(!a.complete()||!b.complete())return "INCOMPLETE";
            if(a.price<=0||b.price<=0)return "NONPOSITIVE_PRICE";
            if(a.qty<0||b.qty<0||a.nord<0||b.nord<0)return "NEGATIVE_SIZE";
            if(i<49 && asks[i].price>=asks[i+1].price)return "ASK_NOT_STRICT";
            if(i<49 && bids[i].price<=bids[i+1].price)return "BID_NOT_STRICT";
        }
        if(bids[0].price>=asks[0].price)return "CROSSED";
        return "OK";
    }

    public static String validateDhan20(Dhan20Decoder.Level[] bids,Dhan20Decoder.Level[] asks){
        if(bids.length!=20||asks.length!=20)return "DEPTH_LENGTH";
        for(int i=0;i<20;i++){
            var b=bids[i]; var a=asks[i];
            if(!Double.isFinite(b.price())||!Double.isFinite(a.price())||b.price()<=0||a.price()<=0)return "NONPOSITIVE_OR_NAN";
            if(b.qty()<0||a.qty()<0||b.nord()<0||a.nord()<0)return "NEGATIVE_SIZE";
            if(i<19 && bids[i].price()<=bids[i+1].price())return "BID_NOT_STRICT";
            if(i<19 && asks[i].price()>=asks[i+1].price())return "ASK_NOT_STRICT";
        }
        if(bids[0].price()>=asks[0].price())return "CROSSED";
        return "OK";
    }
}
