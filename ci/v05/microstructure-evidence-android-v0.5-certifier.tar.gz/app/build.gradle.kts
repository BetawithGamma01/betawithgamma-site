plugins {
    id("com.android.application")
}

fun quoted(s: String): String = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
val v05GitCommit = providers.gradleProperty("v05GitCommit").orElse("UNBOUND_LOCAL").get()
val v05SourceTreeSha = providers.gradleProperty("v05SourceTreeSha256").orElse("UNBOUND_LOCAL").get()
val v05CiRunId = providers.gradleProperty("v05CiRunId").orElse("UNBOUND_LOCAL").get()

android {
    namespace = "com.betawithgamma.microstructure"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.betawithgamma.microstructure"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "0.5.0-decoder-certifier"

        testInstrumentationRunner = "android.test.InstrumentationTestRunner"
        buildConfigField("String", "GIT_COMMIT", quoted(v05GitCommit))
        buildConfigField("String", "SOURCE_TREE_SHA256", quoted(v05SourceTreeSha))
        buildConfigField("String", "CI_RUN_ID", quoted(v05CiRunId))
        buildConfigField("String", "DECODER_VERSION", quoted("v0.5.0-certifier-1"))
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources.excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
    }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
